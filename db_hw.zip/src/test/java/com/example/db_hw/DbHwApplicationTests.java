package com.example.db_hw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbHwApplicationTests {

    @Test
    void contextLoads() {
    }

}
